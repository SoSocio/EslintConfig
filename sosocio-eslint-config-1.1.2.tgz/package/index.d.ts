// Type definitions for @sosocio/eslint-config
import { Linter } from 'eslint';

// Define the ESLint config interface
interface ESLintConfig {
  extends?: string[];
  plugins?: string[];
  rules?: Record<string, any>;
  env?: Record<string, boolean>;
  globals?: Record<string, any>;
  languageOptions?: {
    parser?: any;
    parserOptions?: Record<string, any>;
    globals?: Record<string, any>;
  };
  settings?: Record<string, any>;
}

// Export the default config
declare const config: ESLintConfig;
export default config;
